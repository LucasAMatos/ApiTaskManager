﻿using ApiTaskManager.Models;
using ApiTaskManager.Request;

namespace ApiTaskManager.Interfaces
{
    public interface ITaskManagerService
    {
        Task<List<Projeto>> GetAllAsync();
        Task<Projeto?> GetByIdAsync(int id);
        Task<Projeto> CreateAsync(CreateProjectRequest projeto);
        Task<Projeto?> UpdateAsync(int id, Projeto projetoAtualizado);
        Task<bool> DeleteAsync(int id);
    }
}
